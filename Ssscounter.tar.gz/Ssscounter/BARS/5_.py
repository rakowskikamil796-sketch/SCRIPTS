import os
from PIL import Image, ImageDraw, ImageFont
import glob

# Tworzenie listy wszystkich plików PNG kończących się na _ss.png w bieżącym katalogu
file_list = sorted(glob.glob("*_ss.png"), key=lambda x: int(x.split('_')[0]))

# Inicjalizacja listy do przechowywania obrazów
images = []

# Pętla przez pliki i otwieranie ich
for file in file_list:
    img = Image.open(file)
    draw = ImageDraw.Draw(img)
    
    # Pobieranie numeru klatki z nazwy pliku
    frame_number = file.split('_')[0]
    
    # Ustawienie czcionki i rozmiaru tekstu
    font = ImageFont.truetype("arial.ttf", 36)
    
    # Dodanie numeru klatki w lewym dolnym rogu
    text_position = (10, img.height - 50)
    draw.text(text_position, frame_number, font=font, fill="black")
    
    images.append(img)

# Zapisywanie obrazów jako GIF bez zapętlania
if images:
    images[0].save('total_ss.gif', save_all=True, append_images=images[1:], optimize=False, duration=100, loop=1)
    print("The GIF has been successfully created and saved as total_ss.gif.")

# Usunięcie plików PNG, TXT i BIN po zakończeniu operacji
for file_type in ["*.png", "*.txt", "*.bin"]:
    for file in glob.glob(file_type):
        if file_type == "*.png" and file in ["total_ss_average_difference.png", "logo.png"]:
            continue  # Pomijamy usunięcie tych plików
        os.remove(file)
        print(f"Deleted: {file}")

else:
    print("No PNG files ending with _ss.png were found.")


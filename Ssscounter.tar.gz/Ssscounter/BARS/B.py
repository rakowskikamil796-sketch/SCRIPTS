import re

# Przeczytaj wartość liczbową z pierwszego wiersza pliku AA.txt
with open('AA.bin', 'r') as f:
    value_from_aa = f.readline().strip()

# Przeczytaj zawartość pliku 2_SS_add_protein_matrix.py
with open('2_.py', 'r') as f:
    lines = f.readlines()

# Zdefiniuj numery wierszy do modyfikacji
line_numbers_to_modify = [9, 12, 13, 14]

# Iteruj przez określone wiersze i zamień liczby na wartość z pliku AA.txt, zachowując znak "+"
for line_number in line_numbers_to_modify:
    lines[line_number - 1] = re.sub(r'(\+?\d+)', lambda x: x.group(0)[0] + value_from_aa if x.group(0).startswith('+') else value_from_aa, lines[line_number - 1])

# Specjalne traktowanie dla wiersza 11
lines[10] = re.sub(r'(\+?\d+)', lambda x: x.group(0) if x.group(0) == '0' else (x.group(0)[0] + value_from_aa if x.group(0).startswith('+') else value_from_aa), lines[10])

# Zapisz zmodyfikowaną zawartość z powrotem do pliku 2_SS_add_protein_matrix.py
with open('2_.py', 'w') as f:
    f.writelines(lines)

print("The file '2_.py' has been successfully updated.")


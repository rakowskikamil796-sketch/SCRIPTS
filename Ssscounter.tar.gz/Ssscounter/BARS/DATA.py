import os

def process_tml_file():
    # Pobranie nazwy pliku .tml w bieżącym katalogu
    files = [f for f in os.listdir('.') if f.endswith('.tml')]
    
    if not files:
        print("Brak pliku .tml w bieżącym folderze.")
        return
    
    input_file = files[0]  # Jeśli jest więcej niż jeden plik .tml, wybiera pierwszy
    output_file = f"{os.path.splitext(input_file)[0]}_SS.txt"

    with open(input_file, "r") as infile:
        lines = infile.readlines()

    # Usuwanie linii rozpoczynających się od #
    filtered_lines = [line for line in lines if not line.startswith("#")]

    # Usuwanie od góry linii, gdzie czwarta kolumna ma wartość 0
    processed_lines = []
    for line in filtered_lines:
        columns = line.split()
        if len(columns) >= 4 and columns[3] != "0":
            processed_lines.append(line)

    # Zapis do pliku wynikowego
    with open(output_file, "w") as outfile:
        outfile.writelines(processed_lines)

    print(f"The file has been saved as: {output_file}")

# Uruchomienie funkcji
process_tml_file()


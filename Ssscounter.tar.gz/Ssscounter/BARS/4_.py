import os
import matplotlib.pyplot as plt
from collections import Counter
import numpy as np

# Kolory dla poszczególnych liter
sec_colors = {
    'T': 'lightseagreen',
    'E': 'yellow',
    'B': 'darkkhaki',
    'H': 'orchid',
    'G': 'blue',
    'I': 'red',
    'C': 'whitesmoke'
}

# Funkcja do generowania wykresu słupkowego
def generate_bar_chart(file_name):
    with open(file_name, 'r') as file:
        data = file.read().splitlines()
    
    # Liczenie wystąpień liter
    counter = Counter(data)
    total = sum(counter.values())
    
    # Procenty dla każdej litery
    percentages = {letter: (counter[letter] / total) * 100 for letter in sec_colors.keys()}
    
    # Ustawienie danych do wykresu
    letters = list(sec_colors.keys())
    values = [percentages[letter] for letter in letters]
    colors = [sec_colors[letter] for letter in letters]
    
    # Tworzenie wykresu
    plt.figure(figsize=(10, 6))
    bars = plt.bar(letters, values, color=colors, edgecolor='black')  # Dodanie czarnego obramowania
    
    # Dodanie wartości procentowych nad słupkami
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width() / 2, height, f'{height:.2f}%', ha='center', va='bottom', fontsize=12, fontweight='bold', color='black')
    
    # Ustawienia osi
    plt.ylim(0, 100)
    plt.xlabel('Secondary Structure', fontsize=14, fontweight='bold')
    plt.ylabel('Percentage', fontsize=14, fontweight='bold')  # Pogrubienie podpisu osi Y
    plt.title(f'', fontsize=16)
    
    # Zapisanie wykresu do pliku PNG
    output_file = file_name.replace('_ss.txt', '_ss.png')
    plt.savefig(output_file)
    plt.close()

# Znalezienie plików z końcówką _ss.txt i wygenerowanie wykresów
percentage_compositions_list = []
for file in os.listdir():
    if file.endswith('_ss.txt'):
        generate_bar_chart(file)
        
        with open(file, 'r') as f:
            data = f.read().splitlines()
        
        counter = Counter(data)
        total = sum(counter.values())
        percentages = {letter: (counter[letter] / total) * 100 for letter in sec_colors.keys()}
        percentage_compositions_list.append(percentages)

# Obliczanie średnich procentowych składów i odchyleń standardowych
average_compositions = {letter: np.mean([comp[letter] for comp in percentage_compositions_list]) for letter in sec_colors.keys()}
std_devs = {letter: np.std([comp[letter] for comp in percentage_compositions_list]) for letter in sec_colors.keys()}



# Generowanie wykresu słupkowego dla średnich procentowych składów i odchyleń standardowych
letters = list(sec_colors.keys())
avg_values = [average_compositions[letter] for letter in letters]
std_values = [std_devs[letter] for letter in letters]
colors = [sec_colors[letter] for letter in letters]

plt.figure(figsize=(10, 6))
bars = plt.bar(letters, avg_values, yerr=std_values, color=colors, edgecolor='black', capsize=5)  # Dodanie czarnego obramowania i odchylenia standardowego

# Dodanie wartości średnich nad słupkami z większą odległością
for bar in bars:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width() / 2, height + 10, f'{height:.2f}%', ha='center', va='bottom', fontsize=12, fontweight='bold', color='black')

# Ustawienia osi
plt.ylim(0, 100)
plt.xlabel('Secondary Structure', fontsize=14, fontweight='bold')
plt.ylabel('Average Percentage Composition', fontsize=14, fontweight='bold')  # Pogrubienie podpisu osi Y
plt.title('Average Percentage Compositions with Standard Deviation', fontsize=16)

# Zapisanie wykresu do pliku PNG
plt.savefig('total_ss_average_difference.png')
plt.close()


import tkinter as tk
from PIL import Image, ImageTk
import os

def save_to_file():
    numbers = entry.get()
    with open('AA.bin', 'w') as f:
        f.write(numbers)
    status_label.config(text="OK")

def run_script(script_name):
    if os.path.exists(script_name):
        os.system(f"python {script_name}")
        status_labels[script_name].config(text="OK")
    else:
        status_labels[script_name].config(text="File not found")

def close_window():
    window.destroy()

# Utwórz główne okno
window = tk.Tk()
window.title("Enter the number of amino acids in your protein")

# Wczytaj i wyświetl obraz logo.png
try:
    image = Image.open("logo.png")
    image = image.resize((200, 200))
    logo = ImageTk.PhotoImage(image)
    label = tk.Label(window, image=logo)
    label.pack(pady=10)
except FileNotFoundError:
    print("The logo.png file is missing from the current folder")

# Dodanie etykiety "Step I"
step1_label = tk.Label(window, text="Step I")
step1_label.pack()

# Utwórz pole tekstowe
entry = tk.Entry(window, width=100)
entry.pack(pady=10)

# Utwórz guzik "START", który zapisuje tekst do pliku i wyświetla "OK"
start_button = tk.Button(window, text="ACCEPT", command=save_to_file)
start_button.pack(pady=10)

status_label = tk.Label(window, text="")
status_label.pack()

# Przygotowanie przycisków dla skryptów Step II-IV
steps = [("Step II", "DATA.py"), ("Step III", "B.py"), ("Step IV", "C.py")]
status_labels = {}

for step_name, script_name in steps:
    step_button = tk.Button(window, text=step_name, command=lambda s=script_name: run_script(s))
    step_button.pack(pady=10)

    status_labels[script_name] = tk.Label(window, text="")
    status_labels[script_name].pack()

# Dodanie guzika "Close Window"
close_button = tk.Button(window, text="Close Window", command=close_window)
close_button.pack(pady=10)

# Uruchom aplikację
window.mainloop()


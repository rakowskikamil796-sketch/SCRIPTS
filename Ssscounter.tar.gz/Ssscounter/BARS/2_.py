import os

# Funkcja do przekształcania długiej kolumny w macierz o wielu wierszach i wielu kolumnach
def transform_column_to_matrix(file_path):
    # Odczytywanie zawartości pliku
    with open(file_path, 'r') as file:
        lines = [line.strip() for line in file.readlines()]
    
    # Tworzenie macierzy o 152 wierszach
    matrix = []
    for i in range(0, len(lines), 152):
        column = lines[i:i+152]
        if len(column) < 152:
            column.extend([''] * (152 - len(column)))  # Uzupełnianie brakujących wierszy pustymi wartościami
        matrix.append(column)
    
    # Transponowanie macierzy, aby uzyskać kolumny jako wiersze
    transposed_matrix = list(zip(*matrix))
    
    # Zapisywanie macierzy do nowego pliku z końcówką _secondary.txt
    new_file_path = file_path.replace('_reduced.txt', '_secondary.txt')
    with open(new_file_path, 'w') as new_file:
        for row in transposed_matrix:
            new_file.write(' '.join(row) + '\n')

# Pobieranie listy wszystkich plików _reduced.txt w bieżącym katalogu
files_in_directory = os.listdir('.')

# Przetwarzanie wszystkich plików _reduced.txt w katalogu
for file_name in files_in_directory:
    if file_name.endswith('_reduced.txt'):
        transform_column_to_matrix(file_name)

print("Conversion completed for all _reduced.txt files in the current directory.")

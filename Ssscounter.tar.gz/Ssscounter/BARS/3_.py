import os

# Funkcja do wyodrębniania kolumn i zapisywania ich do osobnych plików
def extract_columns(file_name):
    with open(file_name, 'r') as file:
        lines = file.readlines()
    
    # Transponowanie macierzy, aby uzyskać kolumny jako wiersze
    columns = list(zip(*[line.strip().split() for line in lines]))
    
    # Zapisanie każdej kolumny do osobnego pliku
    for i, column in enumerate(columns):
        with open(f"{i+1}_ss.txt", 'w') as col_file:
            col_file.write('\n'.join(column))

# Znalezienie pliku z końcówką _secondary.txt
for file in os.listdir():
    if file.endswith('_secondary.txt'):
        extract_columns(file)
        break

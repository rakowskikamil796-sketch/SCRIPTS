import os

# Funkcja do usuwania pierwszych czterech kolumn i pozostawiania tylko piątej kolumny
def remove_first_four_columns(file_path):
    # Odczytywanie zawartości pliku
    with open(file_path, 'r') as file:
        lines = file.readlines()
    
    # Wyodrębnianie piątej kolumny
    fifth_column = [line.split()[4] for line in lines if len(line.split()) >= 5]
    
    # Zapisywanie piątej kolumny do nowego pliku z końcówką _reduced.txt
    new_file_path = file_path.replace('.txt', '_reduced.txt')
    with open(new_file_path, 'w') as new_file:
        new_file.write('\n'.join(fifth_column))

# Pobieranie listy wszystkich plików .txt w bieżącym katalogu
files_in_directory = os.listdir('.')

# Przetwarzanie wszystkich plików .txt w katalogu
for file_name in files_in_directory:
    if file_name.endswith('.txt'):
        remove_first_four_columns(file_name)

print("Operation completed for all .txt files in the current directory.")

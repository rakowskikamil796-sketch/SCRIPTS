import subprocess

# Lista plików do uruchomienia w kolejności
files = [
    "1_.py",
    "2_.py",
    "3_.py",
    "4_.py",
    "5_.py",
    "6_.py"
]

# Funkcja do uruchamiania plików
def run_files(file_list):
    for file in file_list:
        try:
            subprocess.run(["python", file], check=True)
            print(f"Successfully ran {file}")
        except subprocess.CalledProcessError as e:
            print(f"Error running {file}: {e}")

# Uruchomienie plików
run_files(files)


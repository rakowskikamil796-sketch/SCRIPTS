import os
import matplotlib.pyplot as plt

# Kolory dla poszczególnych serii
sec_colors = {
    'T': 'lightseagreen',
    'E': 'yellow',
    'B': 'darkkhaki',
    'H': 'orchid',
    'G': 'blue',
    'I': 'red',
    'C': 'grey'
}

# Funkcja do generowania wykresów dla wszystkich wierszy
def plot_series(file_name):
    data = []
    with open(file_name, 'r') as file:
        for line in file:
            data.append(list(map(float, line.strip().split())))
    
    data = list(zip(*data))
    x_values = data[0]  # Pierwsza kolumna to numeracja
    series_labels = ['T', 'E', 'B', 'H', 'G', 'I', 'C']
    
    for row_idx in range(1, len(x_values) + 1):
        fig, axes = plt.subplots(len(series_labels), 1, sharex=True, figsize=(10, 20))

        for i, label in enumerate(series_labels):
            axes[i].plot(x_values, data[i+1], label=label, color=sec_colors[label])
            axes[i].grid(True, linestyle='--', alpha=0.6)
            axes[i].legend(loc='upper right', fontsize=15)  # Zwiększenie czcionki legendy

            # Dodaj pionową czerwoną kreskę i podpis dla wartości z aktualnego wiersza
            row_value = data[i+1][row_idx - 1]
            x_position = x_values[row_idx - 1]  # Dokładna pozycja pionowej kreski

            axes[i].axvline(x=x_position, color='black', linewidth=2)

            # Pobranie granic osi Y
            y_min, y_max = axes[i].get_ylim()

            # Ustalanie pozycji tekstu bliżej pionowej kreski
            text_x_position = x_position + (x_values[-1] - x_values[0]) * 0.01  # Dodanie niewielkiego przesunięcia
            text_y_position = row_value  # Ustawienie dokładnie przy wartości procentowej

            axes[i].text(text_x_position, text_y_position, f'{row_value:.1f}%', color='black', fontsize=15, fontweight='bold', verticalalignment='center')

            if y_min < 0:
                axes[i].set_ylim(bottom=0)

            axes[i].tick_params(axis='y', labelsize=15)  # Zwiększenie rozmiaru liczb opisujących osie Y

        fig.text(0.04, 0.5, "Percentage composition", va='center', rotation='vertical', fontsize=15, fontweight='bold')  # Wspólna etykieta dla osi Y
        axes[-1].set_xlabel("Frame", fontsize=15, fontweight='bold')  # Zwiększenie czcionki osi X
        plt.xticks(fontsize=15, fontweight='bold')  # Zwiększenie czcionki wartości na osi X
        
        plt.savefig(f'{row_idx}_ss.png')
        plt.close(fig)

# Przeszukaj aktualny katalog i znajdź pliki kończące się na "_matrix.txt"
for file_name in os.listdir('.'):
    if file_name.endswith('_matrix.txt'):
        plot_series(file_name)


import os

# Funkcja do obliczania składu procentowego liter w danej kolumnie
def calculate_percentages(column):
    total_count = len(column)
    percentages = {}
    for letter in ['T', 'E', 'B', 'H', 'G', 'I', 'C']:
        percentages[letter] = round(column.count(letter) / total_count * 100, 1)
    return [percentages[letter] for letter in ['T', 'E', 'B', 'H', 'G', 'I', 'C']]

# Funkcja do przetwarzania pliku
def process_file(file_name):
    with open(file_name, 'r') as file:
        matrix = [line.strip().split() for line in file]

    # Zamiana kolumn i wierszy
    matrix_transposed = list(zip(*matrix))

    # Utwórz nową macierz zawierającą wartości procentowe
    new_matrix = [calculate_percentages(column) for column in matrix_transposed]

    # Zapisz nową macierz do pliku
    output_file = file_name.replace("_secondary.txt", "_percent.txt")
    with open(output_file, 'w') as file:
        for row in new_matrix:
            file.write(' '.join(map(str, row)) + '\n')

    # Sprawdź liczbę kolumn w nowej macierzy
    if len(new_matrix) == len(matrix[0]):
        print(f"The new matrix in the {output_file} file has the same number of columns as the original matrix.")
    else:
        print(f"The new matrix in the {output_file} file has a different number of columns than the original matrix.")

# Przeszukaj aktualny katalog i znajdź pliki kończące się na "_secondary.txt"
for file_name in os.listdir('.'):
    if file_name.endswith('_secondary.txt'):
        process_file(file_name)



import os

# Funkcja do przetwarzania pliku
def process_file(file_name):
    with open(file_name, 'r') as file:
        lines = [line.strip().split() for line in file]

    # Dodaj numerację jako pierwszą kolumnę
    for i, line in enumerate(lines, start=1):
        line.insert(0, str(i))

    # Zapisz nową macierz do pliku
    output_file = file_name.replace("_percent.txt", "_matrix.txt")
    with open(output_file, 'w') as file:
        for line in lines:
            file.write(' '.join(line) + '\n')

    print(f"The file {output_file} has been created with numbering as the first column.")

# Przeszukaj aktualny katalog i znajdź pliki kończące się na "_percent.txt"
for file_name in os.listdir('.'):
    if file_name.endswith('_percent.txt'):
        process_file(file_name)


=================================================================
S I M P L E  S E C O N D A R Y  S T R U C T R E  C O U N T E R 

					author: Kamil Rakowski
=================================================================

Preparing the Environment Before Execution

Before running the script, update your Python version and install the required libraries. It is recommended to use Anaconda or Miniconda for package management.
Installing Dependencies

Run the following command in the terminal to install the necessary packages:

pip install pandas numpy matplotlib seaborn scipy scikit-learn plotly bokeh statsmodels altair pillow

Additionally, to ensure proper font rendering, install the ttf-mscorefonts-installer package:

sudo apt-get install ttf-mscorefonts-installer

Once these steps are completed, the environment should be ready for script execution.

NOTE
Please do not paste any files with the .txt extension into the working folder (BARS and CURVES directory), as they will disrupt the software's operation. 

FAQ
The script has stopped and did not generate a GIF file:
Error running 6_.py: Command '['python', '6_.py']' died with <Signals.SIGKILL: 9>.

Possible explanation:
Not enough computing resources (RAM, CPU)


================================================================
Startup Protocol
================================================================
1. Unpack the Archive 

Unpack the Ssscounter.tar.gz file using the following command:

tar -xzvf Ssscounter.tar.gz

----------------------------------------------------------------
2. Add Your VMD File

To run VMD with trajectory files .gro and .xtc, execute the following command in the Linux terminal: 
vmd traj.gro traj.xtc

After loading the trajectory, navigate to "Extensions" -> "Analysis" -> "Timeline". Then, in the Timeline panel, initiate the calculations by selecting "Calculate" -> "Calc. Sec. Struct".
Once the analysis is complete, in the main Timeline panel, select "File" -> "Write data file" and save the generated data under the name file.tml.

You now have everything you need. Paste the generated VMD file (file.tml) into the BARS folder and the CURVES folder.


NOTE
Parts of the script must be run sequentially, as shown below (BARS and CURVES directory):

Open the BARS or CURVES folder:
===============================================================
RUN
===============================================================
I. 

Run the first part of the script:

python3 RUN.py

When the application starts, the message “Enter the number of amino acids in the protein” will appear. You must enter the correct value corresponding to the analyzed protein (text field). In the tutorial example, this value is 152. Then press ACCEPT button. To verify the correct number of amino acids, open the file.tml in a text editor. In the seventh line from the top (# NUM_ITEMS=...), you will find the required value. For the given example, this value is 152. Example of the first lines of the file.tml:

# VMD Timeline data file
# CREATOR= admin
# MOL_NAME= traj.gro
# DATA_TITLE= struct
# FILE_VERSION= 1.4
# NUM_FRAMES= 502 
# NUM_ITEMS= 152
# FREE_SELECTION= 0
#

NOTE
The script automatically removes the initial simulation frame (frame zero) because in file.tml from VMD it is a repeat of the last frame.

----------------------------------------------------------------
II.

Run the second part of the script:

Press Step II button

----------------------------------------------------------------
III.

Run the third part of the script:

Press Step III button

----------------------------------------------------------------
IV. 

Run the fourth part of the script:

Pres Step IV button

NOTE
Upon executing the fourth part of the script, multiple .png files will be generated. For instance, if the trajectory spans 100 ns, the system will produce 1000 .png files, each representing a distinct stage of the analysis. Notably, upon completion of the computational process, the script automatically performs a cleanup operation, removing unnecessary files to optimize disk space usage.


****************Generating the Multimedia File*****************

When the algorithm finishes, it will generate a multimedia file named total_ss.gif. It is recommended to convert this file to mp4 format using available conversion software, which will allow for slowing down the counter's progress. 

CURVES directry:
The labels on the charts and the colors of the curves are consistent with the standards used in VMD software for secondary structure analysis (Timeline module). The CURVES folder stores the percentage value measured by the counter, which is displayed next to it. A black vertical line on the charts precisely indicates the position of the secondary structure counter, facilitating data interpretation. Frame numbering is displayed in the lower-left corner of the screen, enabling quick identification of the desired conformation. It is important to note the difference in frame numbering between VMD and GROMACS. In VMD, numbering starts at 1, whereas in GROMACS, it starts at 0, resulting in a one-frame offset. For example, if the counter registers an important conformation at frame 1001, its corresponding frame in GROMACS will be labeled as 1000.

BARS directory:
After running the algorithm in the BARS directory, the results will be presented as dynamic bar charts saved in the total_ss.gif file. The notation and color scheme for secondary structures remain consistent with the previous format. Additionally, the BARS folder will contain a generated file named total_ss_average_difference.png, which visualizes the mean values and standard deviations in bar chart format.



Pleas cite:

An Effective Method for Determining the Degree of Oligomerization of hnRNPA2 Low Complexity Domain

Paulina Żeliszewska, Zbigniew Adamczyk, Pooja Shah, Kamil Rakowski, Jakub W. Wojciechowski, Aleksandra Wosztyl, Anna Kluza, Aneta Michna, and Anna Bratek-Skicki 


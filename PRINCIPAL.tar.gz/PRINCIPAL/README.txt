README.txt

Description:
The script principal_axes.py calculates the lengths of the principal axes of an ellipsoid fitted to protein structures stored in .pdb files. Based on atomic coordinates, it computes the covariance matrix and derives the axis lengths. Results are saved to a text file and visualized as an interactive 3D plot.

Folder structure:
Place all .pdb files in the same folder as the principal_axes.py script. The script will automatically process all .pdb files located in the current directory.

Required libraries:
To run the script, install the following Python libraries via terminal:

pip install MDAnalysis numpy plotly

It is recommended to use a virtual environment (e.g., venv or conda) to isolate dependencies.

Browser requirement:
To display the interactive 3D plot, a modern web browser must be installed. It is recommended to use Google Chrome for full compatibility with Plotly visualizations.

Running the script:
Execute the script from the terminal using the command:

python3 principal_axes.py

Output:
After execution, the script will generate:

- a folder named "wyniki" containing:
  - axes.txt – average lengths of the principal axes (X, Y, Z) with standard deviations
  - elipsoida.png – a saved PNG image of the ellipsoid visualization

Additionally, the ellipsoid will be displayed in your browser as an interactive 3D plot.

Notes:
If any errors occur while processing .pdb files, the script will print a diagnostic message for each problematic file.

Author: Kamil Rakowski  
Institution: Jerzy Haber Institute of Catalysis and Surface Chemistry, Polish Academy of Sciences  
Date created: 07.10.2025

Pleas cite:

"Mechanism of Ribonucleoprotein Low Complexity Domain Molecule Oligomerization: Experimental Investigations and Theoretical Modeling"

Paulina Żeliszewska, Zbigniew Adamczyk, Pooja Shah, Kamil Rakowski, Jakub W. Wojciechowski, Aleksandra Wosztyl, Anna Kluza, Aneta Michna, and Anna Bratek-Skicki 

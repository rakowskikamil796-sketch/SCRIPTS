import MDAnalysis as mda
import os
import numpy as np
import plotly.graph_objects as go

def principal_axes_lengths(positions):
    # Center coordinates and compute covariance matrix
    coords = positions - np.mean(positions, axis=0)
    cov = np.cov(coords.T)
    eigenvalues = np.linalg.eigvalsh(cov)
    lengths = 2 * np.sqrt(eigenvalues)
    return sorted(lengths)

# Directory containing PDB files
folder_path = "./"
axes_data = []

for filename in os.listdir(folder_path):
    if filename.endswith(".pdb"):
        try:
            u = mda.Universe(os.path.join(folder_path, filename))
            protein = u.select_atoms("protein")
            axes = principal_axes_lengths(protein.positions)
            axes_data.append(axes)
        except Exception as e:
            print(f"Error processing file {filename}: {e}")

# Compute mean and standard deviation of axis lengths
axes_array = np.array(axes_data)
mean_axes = np.mean(axes_array, axis=0)
std_axes = np.std(axes_array, axis=0)

# Create output directory
os.makedirs("results", exist_ok=True)

# Save axis lengths to text file
with open("results/axes.txt", "w") as f:
    f.write("Principal Axes Lengths [Å]:\n")
    f.write(f"X: {mean_axes[0]:.2f} ± {std_axes[0]:.2f}\n")
    f.write(f"Y: {mean_axes[1]:.2f} ± {std_axes[1]:.2f}\n")
    f.write(f"Z: {mean_axes[2]:.2f} ± {std_axes[2]:.2f}\n")

# Ellipsoid parameters (semi-axes)
a, b, c = mean_axes / 2

# Generate ellipsoid wireframe
lines = []

# Meridians
for phi in np.linspace(0, 2 * np.pi, 24):
    theta = np.linspace(0, np.pi, 100)
    x = a * np.cos(phi) * np.sin(theta)
    y = b * np.sin(phi) * np.sin(theta)
    z = c * np.cos(theta)
    lines.append(go.Scatter3d(x=x, y=y, z=z, mode='lines',
                              line=dict(color='gray', width=1), showlegend=False))

# Parallels
for theta in np.linspace(0.1, np.pi - 0.1, 12):
    phi = np.linspace(0, 2 * np.pi, 100)
    x = a * np.cos(phi) * np.sin(theta)
    y = b * np.sin(phi) * np.sin(theta)
    z = c * np.cos(theta) * np.ones_like(phi)
    lines.append(go.Scatter3d(x=x, y=y, z=z, mode='lines',
                              line=dict(color='gray', width=1), showlegend=False))

# Add colored arrows for X, Y, Z axes
arrow_scale = 1.0

arrows = [
    go.Scatter3d(x=[-a * arrow_scale, a * arrow_scale], y=[0, 0], z=[0, 0],
                 mode='lines+markers', line=dict(color='green', width=6),
                 marker=dict(size=2, color='green'), name='X-axis'),
    go.Scatter3d(x=[0, 0], y=[-b * arrow_scale, b * arrow_scale], z=[0, 0],
                 mode='lines+markers', line=dict(color='blue', width=6),
                 marker=dict(size=2, color='blue'), name='Y-axis'),
    go.Scatter3d(x=[0, 0], y=[0, 0], z=[-c * arrow_scale, c * arrow_scale],
                 mode='lines+markers', line=dict(color='red', width=6),
                 marker=dict(size=2, color='red'), name='Z-axis')
]

# Annotation with axis lengths
annotation_text = (
    f"Principal Axes Lengths [Å]:<br>"
    f"X: {mean_axes[0]:.2f} ± {std_axes[0]:.2f}<br>"
    f"Y: {mean_axes[1]:.2f} ± {std_axes[1]:.2f}<br>"
    f"Z: {mean_axes[2]:.2f} ± {std_axes[2]:.2f}"
)

# Create interactive 3D plot
fig = go.Figure(data=lines + arrows)
fig.update_layout(
    title="",
    scene=dict(
        xaxis=dict(title="X [Å]", range=[-15, 15]),
        yaxis=dict(title="Y [Å]", range=[-15, 15]),
        zaxis=dict(title="Z [Å]", range=[-15, 15]),
        aspectmode='manual',
        aspectratio=dict(x=1, y=1, z=1),
        camera=dict(
            eye=dict(x=1.5, y=1.5, z=1.5)
        )
    ),
    legend=dict(
        font=dict(size=24)
    ),
    annotations=[
        dict(
            showarrow=False,
            text=annotation_text,
            xref="paper",
            yref="paper",
            x=0.75,
            y=0.1,
            align="left",
            bgcolor="white",
            bordercolor="gray",
            font=dict(size=12)
        )
    ]
)

# Display plot in browser
fig.show()

# Save plot as PNG
try:
    fig.write_image("results/ellipsoid.png", width=800, height=600)
    print("Image saved as results/ellipsoid.png")
except Exception as e:
    print(f"Failed to save image: {e}")


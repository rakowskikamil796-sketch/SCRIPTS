import MDAnalysis as mda
import os
import numpy as np

def compute_elongation(positions):
    # Compute the inertia tensor
    coords = positions - np.mean(positions, axis=0)
    I = np.zeros((3, 3))
    for x, y, z in coords:
        I[0, 0] += y**2 + z**2
        I[1, 1] += x**2 + z**2
        I[2, 2] += x**2 + y**2
        I[0, 1] -= x * y
        I[0, 2] -= x * z
        I[1, 2] -= y * z
    I[1, 0] = I[0, 1]
    I[2, 0] = I[0, 2]
    I[2, 1] = I[1, 2]

    # Eigenvalues
    eigenvalues = np.linalg.eigvalsh(I)
    λ1, λ2, λ3 = sorted(eigenvalues)

    # Elongation: largest eigenvalue / smallest eigenvalue
    elongation = λ3 / λ1 if λ1 != 0 else np.nan
    return elongation

# Folder containing PDB files
folder_path = "./"
results = []

for filename in os.listdir(folder_path):
    if filename.endswith(".pdb"):
        try:
            u = mda.Universe(os.path.join(folder_path, filename))
            protein = u.select_atoms("protein")
            elong = compute_elongation(protein.positions)
            results.append((filename, elong))
        except Exception as e:
            print(f"Error processing file {filename}: {e}")

# Save results
with open("elongation_output.txt", "w") as f:
    for name, elong in results:
        f.write(f"{name}\t{elong:.6f}\n")

# Statistics
elong_values = [e for _, e in results if not np.isnan(e)]
mean_elong = np.mean(elong_values)
std_elong = np.std(elong_values)

print(f"Mean elongation: {mean_elong:.6f}")
print(f"Standard deviation: {std_elong:.6f}")

with open("elongation_average.txt", "w") as f:
    f.write(f"Mean elongation: {mean_elong:.6f}\n")
    f.write(f"Standard deviation: {std_elong:.6f}\n")


README.txt

Description:
The script elongation.py calculates the elongation of protein structures based on .pdb files. The analysis is derived from the inertia tensor of protein atoms, where elongation is defined as the ratio of the largest to the smallest eigenvalue.

Folder structure:
Place all .pdb files in the same folder as the elongation.py script. The script will automatically process all .pdb files located in the current directory.

Required libraries:
To run the script, install the following Python libraries via terminal:

pip install MDAnalysis numpy

It is recommended to use a virtual environment (e.g., venv or conda) to isolate dependencies.

Running the script:
Execute the script from the terminal using the command:

python3 elongation.py

Output:
After execution, the script will generate two text files:

- elongation_output.txt – contains the elongation values for each processed .pdb file
- elongation_average.txt – contains the average elongation and standard deviation

Notes:
If any errors occur while processing .pdb files, the script will print a diagnostic message for each problematic file.

Author: Kamil Rakowski  
Institution: Jerzy Haber Institute of Catalysis and Surface Chemistry, Polish Academy of Sciences  
Date created: 07.10.2025

Pleas cite:

"Mechanism of Ribonucleoprotein Low Complexity Domain Molecule Oligomerization: Experimental Investigations and Theoretical Modeling"

Paulina Żeliszewska, Zbigniew Adamczyk, Pooja Shah, Kamil Rakowski, Jakub W. Wojciechowski, Aleksandra Wosztyl, Anna Kluza, Aneta Michna, and Anna Bratek-Skicki 

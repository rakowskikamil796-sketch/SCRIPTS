import MDAnalysis as mda
import os
import numpy as np

def compute_asphericity(positions):
    # Compute the inertia tensor
    coords = positions - np.mean(positions, axis=0)
    I = np.zeros((3, 3))
    for x, y, z in coords:
        I[0, 0] += y**2 + z**2
        I[1, 1] += x**2 + z**2
        I[2, 2] += x**2 + y**2
        I[0, 1] -= x * y
        I[0, 2] -= x * z
        I[1, 2] -= y * z
    I[1, 0] = I[0, 1]
    I[2, 0] = I[0, 2]
    I[2, 1] = I[1, 2]

    # Eigenvalues
    eigenvalues = np.linalg.eigvalsh(I)
    λ1, λ2, λ3 = sorted(eigenvalues)

    # Asphericity according to definition
    asp = ((λ1 - λ2)**2 + (λ2 - λ3)**2 + (λ3 - λ1)**2) / (2 * (λ1 + λ2 + λ3)**2)
    return asp

# Folder containing PDB files
folder_path = "./"
results = []

for filename in os.listdir(folder_path):
    if filename.endswith(".pdb"):
        try:
            u = mda.Universe(os.path.join(folder_path, filename))
            protein = u.select_atoms("protein")
            asp = compute_asphericity(protein.positions)
            results.append((filename, asp))
        except Exception as e:
            print(f"Error processing file {filename}: {e}")

# Save results
with open("output.txt", "w") as f:
    for name, asp in results:
        f.write(f"{name}\t{asp:.6f}\n")

# Statistics
asp_values = [asp for _, asp in results]
mean_asp = np.mean(asp_values)
std_asp = np.std(asp_values)

print(f"Mean asphericity: {mean_asp:.6f}")
print(f"Standard deviation: {std_asp:.6f}")

with open("asphericity_average.txt", "w") as f:
    f.write(f"Mean asphericity: {mean_asp:.6f}\n")
    f.write(f"Standard deviation: {std_asp:.6f}\n")


README.txt

Description:
The script asphericity.py calculates the asphericity of protein structures based on .pdb files. The analysis is based on the inertia tensor of protein atoms.

Folder structure:
Place all .pdb files in the same folder as the asphericity.py script. The script will automatically process all .pdb files located in the current directory.

Required libraries:
To run the script, install the following Python libraries via terminal:

pip install MDAnalysis numpy

It is recommended to use a virtual environment (e.g., venv or conda) to isolate dependencies.

Running the script:
Execute the script from the terminal using the command:

python3 asphericity.py

Output:
After execution, the script will generate two text files:

- output.txt – contains the asphericity values for each processed .pdb file
- asphericity_average.txt – contains the average asphericity and standard deviation

Notes:
If any errors occur while processing .pdb files, the script will print a diagnostic message for each problematic file.

Author: Kamil Rakowski  
Institution: Jerzy Haber Institute of Catalysis and Surface Chemistry, Polish Academy of Sciences  
Date created: 07.10.2025


Pleas cite:

An Effective Method for Determining the Degree of Oligomerization of hnRNPA2 Low Complexity Domain

Paulina Żeliszewska, Zbigniew Adamczyk, Pooja Shah, Kamil Rakowski, Jakub W. Wojciechowski, Aleksandra Wosztyl, Anna Kluza, Aneta Michna, and Anna Bratek-Skicki 
